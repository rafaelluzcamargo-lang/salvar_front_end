# Ficha da rodada

**Equipe:** Eventos

**Rodada:** 1 (Estrutura)

**Data:** [CONFIRMAR] data de hoje

## Quem foi cada papel

- Diretor de prompt: [CONFIRMAR] nome
- Revisor: [CONFIRMAR] nome
- Testador: [CONFIRMAR] nome
- Conteúdo: [CONFIRMAR] nome

## Prompt usado (colar)

```text
Equipe Eventos, Rodada 1.

Crie uma seção chamada Eventos que deve conter os 3 eventos do Colégio
Estadual Barbosa Ferraz (SETEC, Arraia do Barbosa, Seminário de Formação
de Docentes) e os projetos semanais (Programa Mais Aprendizagem,
Treinamento de Basquetebol, Projeto Altas Habilidades).

Cores desejadas: #4169e1, #004C94, #011142, #14293A, Orange, #fff52b.
Fonte desejada: "Raleway", Arial, Helvetica, sans-serif.

Resposta da IA: as cores em hexadecimal e a fonte Raleway não podem entrar
em paginas/eventos/. A paleta e a fonte têm que ser definidas pela equipe
Identidade visual em compartilhado/estilo.css (REGRAS.md, seções 1, 2 e 5).
Nesta rodada a seção foi feita usando as variáveis que já existem, e as
pendências ficaram marcadas com [CONFIRMAR] (REGRAS.md, seção 6).
```

## O que a IA devolveu (trecho principal)

```text
Arquivo: paginas/eventos/index.html (substituir o arquivo inteiro)

O arquivo tem, dentro do <main>:
- <h1>Eventos</h1> (o único h1 da página)
- <p class="eventos-intro"> com o texto de abertura
- <section> "Eventos": três <article class="card eventos-card">, um para
  cada evento (SETEC, Arraia do Barbosa, Seminário de Formação de Docentes)
- <section> "Projetos semanais": três <article class="card eventos-card">
  (Programa Mais Aprendizagem, Treinamento de Basquetebol, Projeto Altas
  Habilidades)
- <section> "Recados": marcador para a Rodada 2

O esqueleto da página (head, div#menu, div#rodape, data-pagina e a ordem dos
scripts) não foi alterado. pagina.css e pagina.js continuam vazios, porque
estilo é da Rodada 2 e o filtro simples é da Rodada 3.
```

## O que o Revisor explicou sobre o código (3 linhas)

1. [CONFIRMAR] o Revisor preenche depois de revisar.
2. [CONFIRMAR] o Revisor preenche depois de revisar.
3. [CONFIRMAR] o Revisor preenche depois de revisar.

## O que o Testador viu quebrar

- Nada nesta rodada, ou o Testador escreve aqui o que achou.

## Itens [CONFIRMAR] pendentes

### Conteúdo dos eventos (Rodada 3)

- [x] SETEC: dias 12 e 13 de novembro, no Colégio Estadual Barbosa Ferraz,
      organizada pelos alunos do Desenvolvimento de Sistemas.
      Dia 12 (manhã, tarde e noite) e Dia 13 (manhã e tarde).
      A equipe corrigiu as datas durante a rodada: eram 4, 5 e 6 de novembro em
      três dias, e passaram para 12 e 13 de novembro em dois dias. O terceiro
      dia, que era só de manhã, saiu do card.
- [CONFIRMAR] o ano do SETEC (a equipe informou só o dia e o mês).
- [CONFIRMAR] o que é o SETEC além de ser organizado pelo Desenvolvimento de
      Sistemas (o que o evento apresenta, quantas turmas participam, se é
      aberto a outras escolas).
- [CONFIRMAR] horários exatos de cada turno do SETEC (o nome do turno está
      confirmado, a hora de início e de fim não).
- [CONFIRMAR] data, horário, local e público da Arraia do Barbosa.
- [CONFIRMAR] data, horário, local e público do Seminário de Formação de Docentes.

### Conteúdo dos projetos semanais (Rodada 3)

- [CONFIRMAR] dia, horário, local e público do Programa Mais Aprendizagem.
- [CONFIRMAR] dia, horário, local e público do Treinamento de Basquetebol.
- [CONFIRMAR] dia, horário, local e público do Projeto Altas Habilidades.

### Estilo (pedido para a equipe Identidade visual)

- [ ] Issue aberta para a paleta de cores do colégio (#4169e1, #004C94,
      #011142, #14293A, Orange, #fff52b). Essas cores têm que virar variáveis
      em compartilhado/estilo.css, não ficar em pagina.css (REGRAS.md, seção 5).
- [ ] Issue aberta para a fonte "Raleway", Arial, Helvetica, sans-serif, em
      compartilhado/estilo.css (REGRAS.md, seções 1 e 2).
- [ ] Conferir o contraste de #fff52b (amarelo) com texto escuro, porque
      amarelo sobre branco não tem contraste suficiente (Rodada 3 da Identidade).

## Print da página no celular

Salve o print na pasta `imagens/` da equipe e coloque o link aqui, trocando N pelo número da rodada:

`![Print da página no celular](../imagens/print-rodada-N.png)`

(Print no celular é obrigatório a partir da Rodada 4.)
